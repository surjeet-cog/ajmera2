
<?php
ob_start();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../../dbc.php';

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}



$years = [];
$yearResult = $conn->query("
    SELECT DISTINCT financial_year
    FROM secretarial_compliance_reports
    WHERE financial_year <> ''
    ORDER BY financial_year DESC
");

if ($yearResult) {
    while ($row = $yearResult->fetch_assoc()) {
        $years[] = (string)$row['financial_year'];
    }
}

$selectedYear = trim($_GET['financial_year'] ?? '');
$statusFilter = $_GET['status'] ?? '';

$sql = "SELECT id, title, financial_year, pdf_file, status
        FROM secretarial_compliance_reports
        WHERE 1=1";

if ($selectedYear !== '') {
    $sql .= " AND financial_year = ?";
}

if ($statusFilter === '0' || $statusFilter === '1') {
    $sql .= " AND status = ?";
}

$sql .= " ORDER BY financial_year DESC, id DESC";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    error_log('Reports list query failed: ' . $conn->error);
    exit('Unable to load reports.');
}

if ($selectedYear !== '' && in_array($statusFilter, ['0', '1'], true)) {
    $status = (int)$statusFilter;
    $stmt->bind_param('si', $selectedYear, $status);
} elseif ($selectedYear !== '') {
    $stmt->bind_param('s', $selectedYear);
} elseif (in_array($statusFilter, ['0', '1'], true)) {
    $status = (int)$statusFilter;
    $stmt->bind_param('i', $status);
}

$stmt->execute();
$result = $stmt->get_result();

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3>Secretarial Compliance Reports</h3>
        <a href="add.php" class="btn btn-primary">+ Add Report</a>
    </div>

    <?php if (!empty($_SESSION['flash_message'])): ?>
        <div class="alert alert-info">
            <?= h($_SESSION['flash_message']) ?>
        </div>
        <?php unset($_SESSION['flash_message']); ?>
    <?php endif; ?>

    <form method="GET" class="row g-2 mb-4">
        <div class="col-md-3">
            <select name="financial_year" class="form-select">
                <option value="">All Financial Years</option>
                <?php foreach ($years as $year): ?>
                    <option value="<?= h($year) ?>"
                        <?= $selectedYear === $year ? 'selected' : '' ?>>
                        FY <?= h($year) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="col-md-3">
            <select name="status" class="form-select">
                <option value="">All Statuses</option>
                <option value="1" <?= $statusFilter === '1' ? 'selected' : '' ?>>Active</option>
                <option value="0" <?= $statusFilter === '0' ? 'selected' : '' ?>>Inactive</option>
            </select>
        </div>

        <div class="col-md-3">
            <button type="submit" class="btn btn-dark">Filter</button>
            <a href="index.php" class="btn btn-secondary">Reset</a>
        </div>
    </form>

    <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Financial Year</th>
                    <th>Title</th>
                    <th>PDF</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result->num_rows > 0): ?>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= (int)$row['id'] ?></td>
                        <td><?= h($row['financial_year']) ?></td>
                        <td><?= h($row['title']) ?></td>
                        <td>
                            <?php if (!empty($row['pdf_file'])): ?>
                                <a href="/ajmera/<?= h(ltrim($row['pdf_file'], '/')) ?>"
                                   target="_blank" rel="noopener noreferrer">View PDF</a>
                            <?php else: ?>
                                -
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= (int)$row['status'] === 1
                                ? '<span class="badge bg-success">Active</span>'
                                : '<span class="badge bg-secondary">Inactive</span>' ?>
                        </td>
                        <td>
                            <a href="edit.php?id=<?= (int)$row['id'] ?>"
                               class="btn btn-sm btn-warning">Edit</a>

                            <form action="delete.php" method="POST" class="d-inline"
                                  onsubmit="return confirm('Delete this report?');">
                                <input type="hidden" name="id" value="<?= (int)$row['id'] ?>">
                                <input type="hidden" name="csrf_token"
                                       value="<?= h($_SESSION['csrf_token']) ?>">
                                <button type="submit" class="btn btn-sm btn-danger">
                                    Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" class="text-center">No reports found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
$stmt->close();
require_once __DIR__ . '/../includes/footer.php';
?>
