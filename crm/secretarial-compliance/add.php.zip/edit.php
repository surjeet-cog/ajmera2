
<?php
ob_start();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../../dbc.php';

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$id = filter_input(
    INPUT_POST,
    'id',
    FILTER_VALIDATE_INT
);

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
}

if (!$id || $id < 1) {
    $_SESSION['flash_message'] = 'Invalid report ID.';
    header('Location: index.php');
    exit;
}

$stmt = $conn->prepare("
    SELECT id, title, financial_year, pdf_file, status
    FROM secretarial_compliance_reports
    WHERE id = ?
    LIMIT 1
");
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$report = $result->fetch_assoc();
$stmt->close();

if (!$report) {
    $_SESSION['flash_message'] = 'Report not found.';
    header('Location: index.php');
    exit;
}

$title = $report['title'];
$year = $report['financial_year'];
$status = (int)$report['status'];
$oldPdf = $report['pdf_file'];
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf_token'] ?? '';
    $title = trim($_POST['title'] ?? '');
    $year = trim($_POST['financial_year'] ?? '');
    $status = (int)($_POST['status'] ?? -1);

    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        $error = 'Invalid session token. Refresh and try again.';
    } elseif ($title === '' || $year === '') {
        $error = 'Title and financial year are required.';
    } elseif (!in_array($status, [0, 1], true)) {
        $error = 'Invalid status.';
    } else {
        $newPdf = $oldPdf;
        $newFilePath = '';
        $errorUpload = '';

        if (isset($_FILES['pdf_file']) &&
            $_FILES['pdf_file']['error'] !== UPLOAD_ERR_NO_FILE) {

            if ($_FILES['pdf_file']['error'] !== UPLOAD_ERR_OK) {
                $errorUpload = 'PDF upload failed.';
            } elseif ($_FILES['pdf_file']['size'] > 10 * 1024 * 1024) {
                $errorUpload = 'PDF must be 10 MB or smaller.';
            } else {
                $tmp = $_FILES['pdf_file']['tmp_name'];
                $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);

                if ($mime !== 'application/pdf') {
                    $errorUpload = 'Only PDF files are allowed.';
                } else {
                    $uploadDir = __DIR__ . '/../../uploads/secretarial-compliance/';

                    if (!is_dir($uploadDir) &&
                        !mkdir($uploadDir, 0755, true) &&
                        !is_dir($uploadDir)) {
                        $errorUpload = 'Unable to create upload directory.';
                    } else {
                        $filename = bin2hex(random_bytes(16)) . '.pdf';
                        $newFilePath = $uploadDir . $filename;

                        if (move_uploaded_file($tmp, $newFilePath)) {
                            $newPdf = 'uploads/secretarial-compliance/' . $filename;
                        } else {
                            $errorUpload = 'Unable to save new PDF.';
                            $newFilePath = '';
                        }
                    }
                }
            }
        }

        if ($errorUpload !== '') {
            $error = $errorUpload;
        } else {
            $update = $conn->prepare("
                UPDATE secretarial_compliance_reports
                SET title = ?, financial_year = ?, pdf_file = ?, status = ?
                WHERE id = ?
            ");

            if (!$update) {
                $error = 'Database error: ' . $conn->error;
            } else {
                $update->bind_param(
                    'sssii',
                    $title,
                    $year,
                    $newPdf,
                    $status,
                    $id
                );

                if ($update->execute()) {
                    $update->close();

                    if ($newFilePath !== '' &&
                        strpos($oldPdf, 'uploads/secretarial-compliance/') === 0) {
                        $oldPath = __DIR__ . '/../../' . $oldPdf;

                        if (is_file($oldPath)) {
                            @unlink($oldPath);
                        }
                    }

                    $_SESSION['flash_message'] = 'Report updated successfully.';
                    header('Location: index.php');
                    exit;
                }

                $error = 'Update failed: ' . $update->error;
                $update->close();

                if ($newFilePath !== '' && is_file($newFilePath)) {
                    @unlink($newFilePath);
                }
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid py-4">
    <h3 class="mb-4">Edit Secretarial Compliance Report</h3>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?= (int)$id ?>">
        <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">

        <div class="mb-3">
            <label class="form-label">Financial Year</label>
            <input type="text" name="financial_year" class="form-control"
                   value="<?= h($year) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Report Title</label>
            <input type="text" name="title" class="form-control"
                   value="<?= h($title) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Current PDF</label><br>
            <?php if ($oldPdf !== ''): ?>
                <a href="/ajmera/<?= h(ltrim($oldPdf, '/')) ?>"
                   target="_blank" rel="noopener noreferrer">View Current PDF</a>
            <?php else: ?>
                No PDF uploaded.
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Replace PDF (optional, max 10 MB)</label>
            <input type="file" name="pdf_file" class="form-control"
                   accept=".pdf,application/pdf">
        </div>

        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="1" <?= $status === 1 ? 'selected' : '' ?>>Active</option>
                <option value="0" <?= $status === 0 ? 'selected' : '' ?>>Inactive</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Update Report</button>
        <a href="index.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
