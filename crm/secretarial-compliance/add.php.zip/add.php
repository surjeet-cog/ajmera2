
<?php
ob_start();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../../dbc.php';

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$error = '';
$title = '';
$year = '';
$status = 1;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $year = trim($_POST['financial_year'] ?? '');
    $status = (int)($_POST['status'] ?? 1);
    $token = $_POST['csrf_token'] ?? '';

    if (!hash_equals($_SESSION['csrf_token'], $token)) {
        $error = 'Invalid session token. Refresh and try again.';
    } elseif ($title === '' || $year === '') {
        $error = 'Title and financial year are required.';
    } elseif (!in_array($status, [0, 1], true)) {
        $error = 'Invalid status.';
    } elseif (!isset($_FILES['pdf_file']) ||
              $_FILES['pdf_file']['error'] !== UPLOAD_ERR_OK) {
        $error = 'Please select a PDF file.';
    } elseif ($_FILES['pdf_file']['size'] > 10 * 1024 * 1024) {
        $error = 'PDF must be 10 MB or smaller.';
    } else {
        $tmp = $_FILES['pdf_file']['tmp_name'];
        $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);

        if ($mime !== 'application/pdf') {
            $error = 'Only PDF files are allowed.';
        } else {
            $uploadDir = __DIR__ . '/../../uploads/secretarial-compliance/';

            if (!is_dir($uploadDir) &&
                !mkdir($uploadDir, 0755, true) &&
                !is_dir($uploadDir)) {
                $error = 'Unable to create upload directory.';
            } else {
                $filename = bin2hex(random_bytes(16)) . '.pdf';
                $destination = $uploadDir . $filename;
                $relativePath = 'uploads/secretarial-compliance/' . $filename;

                if (!move_uploaded_file($tmp, $destination)) {
                    $error = 'Unable to upload PDF.';
                } else {
                    $stmt = $conn->prepare("
                        INSERT INTO secretarial_compliance_reports
                            (title, financial_year, pdf_file, status)
                        VALUES (?, ?, ?, ?)
                    ");

                    if (!$stmt) {
                        @unlink($destination);
                        $error = 'Database error: ' . $conn->error;
                    } else {
                        $stmt->bind_param('sssi', $title, $year, $relativePath, $status);

                        if ($stmt->execute()) {
                            $stmt->close();
                            $_SESSION['flash_message'] = 'Report added successfully.';
                            header('Location: index.php');
                            exit;
                        }

                        @unlink($destination);
                        $error = 'Unable to save report: ' . $stmt->error;
                        $stmt->close();
                    }
                }
            }
        }
    }
}

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container-fluid py-4">
    <h3 class="mb-4">Add Secretarial Compliance Report</h3>

    <?php if ($error !== ''): ?>
        <div class="alert alert-danger"><?= h($error) ?></div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>">

        <div class="mb-3">
            <label class="form-label">Financial Year</label>
            <input type="text" name="financial_year" class="form-control"
                   placeholder="2025-26" value="<?= h($year) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Report Title</label>
            <input type="text" name="title" class="form-control"
                   value="<?= h($title) ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">PDF (maximum 10 MB)</label>
            <input type="file" name="pdf_file" class="form-control"
                   accept=".pdf,application/pdf" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Status</label>
            <select name="status" class="form-select">
                <option value="1" <?= $status === 1 ? 'selected' : '' ?>>Active</option>
                <option value="0" <?= $status === 0 ? 'selected' : '' ?>>Inactive</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Save Report</button>
        <a href="index.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
