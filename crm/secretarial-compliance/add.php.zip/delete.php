
<?php
ob_start();

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// require_once __DIR__ . '/../auth.php';
require_once __DIR__ . '/../../dbc.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['flash_message'] = 'Session expired. Please try again.';
    header('Location: index.php');
    exit;
}

$token = $_POST['csrf_token'] ?? '';

if (!hash_equals($_SESSION['csrf_token'], $token)) {
    $_SESSION['flash_message'] = 'Invalid security token. Refresh and try again.';
    header('Location: index.php');
    exit;
}

$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT);

if (!$id || $id < 1) {
    $_SESSION['flash_message'] = 'Invalid report ID.';
    header('Location: index.php');
    exit;
}

// Get PDF path before deleting the record
$stmt = $conn->prepare("
    SELECT pdf_file
    FROM secretarial_compliance_reports
    WHERE id = ?
    LIMIT 1
");

if (!$stmt) {
    $_SESSION['flash_message'] = 'Database error while finding report.';
    header('Location: index.php');
    exit;
}

$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$report = $result->fetch_assoc();
$stmt->close();

if (!$report) {
    $_SESSION['flash_message'] = 'Report not found.';
    header('Location: index.php');
    exit;
}

// Delete database record
$delete = $conn->prepare("
    DELETE FROM secretarial_compliance_reports
    WHERE id = ?
");

if (!$delete) {
    $_SESSION['flash_message'] = 'Database error while deleting report.';
    header('Location: index.php');
    exit;
}

$delete->bind_param('i', $id);

if ($delete->execute()) {
    $delete->close();

    $pdf = (string)$report['pdf_file'];

    // Delete only PDFs belonging to this module's upload directory.
    if (strpos($pdf, 'uploads/secretarial-compliance/') === 0) {
        $baseDir = realpath(__DIR__ . '/../../uploads/secretarial-compliance');
        $filePath = realpath(__DIR__ . '/../../' . $pdf);

        if ($baseDir && $filePath &&
            strpos($filePath, $baseDir . DIRECTORY_SEPARATOR) === 0 &&
            is_file($filePath)) {
            @unlink($filePath);
        }
    }

    $_SESSION['flash_message'] = 'Report deleted successfully.';
} else {
    $_SESSION['flash_message'] = 'Delete failed: ' . $delete->error;
    $delete->close();
}

header('Location: index.php');
exit;
